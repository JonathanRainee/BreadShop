//
//  ViewController.swift
//  jrqlf
//
//  Created by prk on 29/04/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

